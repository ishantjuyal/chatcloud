This is a wordcloud library which allows you to create and save a wordcloud of your whatsapp chats

